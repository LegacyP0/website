x = 0;
ops = "n";
token = 0;

window.onload = function () {
    var onTaps = document.getElementById('content').getElementsByTagName("input");
    for (i = 0; i < onTaps.length; i++) {
        onTaps[i].ontouchstart = function () {
            this.style.background = "url(" + this.id + ".png)";
        }
        onTaps[i].ontouchend = function () {
            this.style.background = 'none';
	     calc(this.name.toString());
        }
    }
}

function calc(op) {
    if (!isNaN(op) || op == ".") {
        if (!token) {
            if (document.getElementById('win').innerHTML.toString() == '0') {
		  if(op == ".") {
                   document.getElementById('win').innerHTML = "0" + op;
		  } else {
                   document.getElementById('win').innerHTML = op;
		  }
            } else {
                document.getElementById('win').innerHTML = document.getElementById('win').innerHTML + op;
            }
        } else {
            document.getElementById('win').innerHTML = op;
            token = 0;
        }
        return;
    } else {
        if (op == "C") {
            document.getElementById('win').innerHTML = 0;
            token = 0;
            return;
        }

        if (op == "CE") {
            document.getElementById('win').innerHTML = 0;
            return;
        }

        if (op == "%") {
            document.getElementById('win').innerHTML = document.getElementById('win').innerHTML / 100.0;
            token = 1;
            return;
        }

        if (op == "+/-") {
            document.getElementById('win').innerHTML = -document.getElementById('win').innerHTML;
            token = 1;
            return;
        }

        if (op == "+" || op == "*" || op == "/" || op == "-" || op == "=") {
            token = 1;
            if (ops != "n") {
                if (ops == "+") {
                    x = x - (-document.getElementById('win').innerHTML);
                    document.getElementById('win').innerHTML = x;
                }
                if (ops == "-") {
                    x = x - document.getElementById('win').innerHTML;
                    document.getElementById('win').innerHTML = x;
                }
                if (ops == "/") {
                    x = x / document.getElementById('win').innerHTML;
                    document.getElementById('win').innerHTML = x;
                }
                if (ops == "*") {
                    x = x * document.getElementById('win').innerHTML;
                    document.getElementById('win').innerHTML = x;
                }
            } else {
                x = document.getElementById('win').innerHTML;
            }
            if (op != "=") {
                ops = op;
            } else {
                ops = "n";
            }
            return;
        }
    }
}
