/* 
 * Style File - jQuery plugin for styling file input elements (Modified!)
 *  
 * Copyright (c) 2007-2008 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Based on work by Shaun Inman
 *   http://www.shauninman.com/archive/2007/09/10/styling_file_inputs_with_css_and_the_dom
 *
 * Revision: $Id: jquery.filestyle.js 303 2008-01-30 13:53:24Z tuupola $
 *
 */

(function($) {
	
	$.fn.filestyle = function(options) {

		var settings = {
			width : 60
		};

		if (options) {
			$.extend(settings, options);
		};

		return this.each(function() {
			
			var self = this;
			var wrapper = $("<div>", {
				'class': 'filestyle'
			}).css({
				"position": "relative"
			});

			var filename = $('<input>')
				.attr('id' , $(self).attr('id') + '_surrogate')
				.attr('type' , 'text')
				.attr('readonly' , 'readonly');

			$(self).before(filename);
			$(self).wrap(wrapper);

			var button = $(self).before($("<button>", {
				'html': 'Browse'
			}));

			$(self).css({
				"position": "absolute",
				"cursor": "pointer",
				"opacity": "0",
				"left": "0",
				"top": "0"
			});

			if ($.browser.mozilla) {
				if (/Win/.test(navigator.platform)) {
					//$(self).css("margin-left", "-142px");
				} else {
					//$(self).css("margin-left", "-168px");
				};
			} else {
				//$(self).css("margin-left", "0px");
			};

			$(self).bind("change", function() {
				var newFilename = $("#" + self.id ).val();
				if( newFilename)
					newFilename = newFilename.replace(/^.*[\\\/]/, '');
				filename.val(newFilename);
			});

		});

	};

})(jQuery);

function clearFilePicker (fp) {
	$(fp).after($(fp).clone(true)).remove();
	$(fp).val('');
	$(fp + "_surrogate").val('');
}