var idTitleRss;
var feed;
var isCelsius=true;
var useRealFeel = false //true|false
var enableWallpaper = false; //true|false
var enableLockScreen = true; //true|false [Currently, it is suggested that the lockScreen is disabled.]
var stylesheetWall = 'oneLine' //'originalBubble'|'myopia'|'iconOnly'|'split'|'oneLine'
var stylesheetLock = 'twoLine' //See above.
var iconSetWall = 'klear' //'klear'|'tango'
var iconExtWall = ".png" //'.png'|.'gif' etc.
var iconSetLock = 'minis' //See above.
var iconExtLock = '.png' //See above.
var source = 'appleAccuweatherStolen' //'appleAccuweatherStolen'|'yahooWeather'
var updateInterval = 35 //Minutes
var idTitleRss;var feed;var useRealFeel = false;var enableWallpaper = false;var enableLockScreen = true;var stylesheetWall = 'oneLine';var stylesheetLock = 'twoLine';var iconSetWall = 'klear';var iconExtWall = ".png";var iconSetLock = 'minis';var iconExtLock = '.png';var source = 'appleAccuweatherStolen';var updateInterval = 35;
