main(){
####nohup
flag=/var/tmp/runkbdrm
if [ ! -f $flag ]; then
	echo "" >> $flag
fi
if [ ! -f $flag ]; then
	echo $flag create fail
fi
launchctl  load  /System/Library/LaunchDaemons/com.ijinshan.kbdrm.plist 
}
main >> /var/tmp/kBatteryDownload.log 2>&1;

