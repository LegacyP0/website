dpkg -r com.ijinshan.kbatterydoctorpro
dpkg -r com.ijinshan.kbatterydoctorpro.universal
dpkg -r app.weiphone.ijinshan.kbatterydoctorpro