//
//  SWGestureMusicControlsPrefs.h
//  SWGestureMusicControls
//
//  Created by Pat Sluth on 2/1/2014.
//
//

#import "SWGestureMusicControlsPrefsController.h"

typedef enum {
    SW_GMC_ANIM_TYPE_SLIDE_OFF = 0,
    SW_GMC_ANIM_TYPE_BOUNCE_BACK = 1
} SW_GMC_ANIM_TYPE;

typedef enum {
    SW_GMC_SWC_LEFT_PREV_RIGHT_NEXT = 0,
    SW_GMC_SWC_LEFT_NEXT_RIGHT_PREV = 1
} SW_GMC_SWIPE_CONTROL_DIRECTION_OPTION;

@interface SWGestureMusicControlsPrefs : NSObject
{
}

+ (NSDictionary *)preferences;

+ (BOOL)enabledForLockScreen;
+ (BOOL)enabledForControlCenter;
+ (BOOL)enabledForMusicApp;
+ (NSString *)sharingHashtag;

+ (SW_GMC_ANIM_TYPE)animationType;

+ (SW_GMC_SWIPE_CONTROL_DIRECTION_OPTION)swipeControlDirection;

+ (BOOL)sharingEnabled;
+ (BOOL)actionIndicatorEnabled;
+ (BOOL)skip15SecondsEnabled;

@end
