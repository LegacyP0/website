var localizedStrings = new Array;

localizedStrings['ERROR'] = 'ERRORE';
localizedStrings['DIV BY ZERO'] = 'DIV PER ZERO';
*/
