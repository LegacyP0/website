gpSPhone
www.zodttd.com
GBA emulator for the iPhone and iTouch
Ported and Developed By ZodTTD
Bug fixes and GUI By NerveGas
A port of gpSP originally developed By Exophase
Controller Artwork by IzFerris (v1.5.0 to current)
Controller Artwork by Scottmandoo and Hazed (v1.1.1 to current)
Controller Artwork by Nuclear Potato (v1.0.0 to v1.1.0 releases)
Controller Artwork by Lajic (v0.5.0 to v1.0.0 releases)
Icon Artwork by Eric of ipodtouchfans.com

For more information about gpSPhone head to it's homepage at http://www.zodttd.com

Sources are available at www.zodttd.com

Tips:
- Use USA region games as they tend to go faster in gpSPhone due to gpsp_config.txt file configuration for game's idle loop elimination (an optimization).
- Need help? Use the forums at www.zodttd.com ...official home of gpSPhone.

Installation:
YOU MUST HAVE THE CORRECT gba_bios.bin FILE INSTALLED FOR THIS EMULATOR TO WORK!
- Place gba_bios.bin (GBA BIOS) in /Applications/gpSPhone.app/
- Place ROMs in /var/mobile/Media/ROMs/GBA/

About the bios (from Exophase's PSP's gpSP readme.txt) ...

Q) How do I know I have the right BIOS?

A) If you have md5sum you can check if it has this hash:
   a860e8c0b6d573d191e4ec7db1b1e4f6
   That BIOS should work fine. I think that some others work fine too,
   although I haven't confirmed this with absolute certainty. It's also
   theoretically possible to use custom (and free) BIOS replacements,
   but I don't know of any publically availablone ones.

   As far as I'm aware there are two BIOSes floating around, I doubt
   you'll get one that isn't one of those two. There's a very easy way
   to determine which one you have - just look at the very first byte in
   a hex editor. The correct BIOS begins with 0x18, the buggy BIOS begins
   with 0x14.