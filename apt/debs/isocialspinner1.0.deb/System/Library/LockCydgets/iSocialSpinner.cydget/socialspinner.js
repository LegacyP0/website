var social = {

	el: null,

	controller: null,

	angle: 0,

	startAngle: 0,

	slices: Math.PI/6,	// 12 slices

	originX: 160,

	originY: 160,

	values: { 11: 'Digg', 10: 'Reddit', 9: 'Newsvine', 8: 'Delicious', 7: 'Stumbleupon', 6: 'Facebook', 5: 'friendfeed', 4: 'Mixx', 3: 'MySpace', 2: 'Netvibes', 1: 'Technorati', 0: 'Twitter' },



	handleEvent: function (e) {

		if (e.type == 'touchstart') {

			this.rotateStart(e);

		} else if (e.type == 'touchmove') {

			this.rotateMove(e);

		} else if (e.type == 'touchend') {

			this.rotateStop(e);

		}

	},



	init: function() {

		this.el = document.getElementById('social');

		this.controller = document.getElementById('display1');

		this.el.style.webkitTransitionDuration = '0';

		

		this.controller.addEventListener('touchstart', this, false);

	},

	

	rotateStart: function(e) {

		e.preventDefault();

		

		this.el.style.webkitTransitionDuration = '0';

		

		var startX = e.touches[0].pageX - this.originX;

		var startY = e.touches[0].pageY - this.originY;

		this.startAngle = Math.atan2(startY, startX) - this.angle;

		

		this.controller.addEventListener('touchmove', this, false);

		this.controller.addEventListener('touchend', this, false);

	},

	

	rotateMove: function(e) {

		var dx = e.touches[0].pageX - this.originX;

		var dy = e.touches[0].pageY - this.originY;

		this.angle = Math.atan2(dy, dx) - this.startAngle;



		this.el.style.webkitTransform = 'rotateZ(' + this.angle + 'rad)';

	},

	

	rotateStop: function(e) {

		this.controller.removeEventListener('touchmove', this, false);

		this.controller.removeEventListener('touchend', this, false);

		

		if( this.angle%this.slices ) {

			this.angle = Math.round(this.angle/this.slices) * this.slices;

			this.el.style.webkitTransitionDuration = '150ms';

			this.el.style.webkitTransform = 'rotateZ(' + this.angle + 'rad)';

		}

	},

	

	getSelectedValue: function() {

		var selected = Math.floor(Math.abs(this.angle)/this.slices/12);

		if (this.angle < 0)

			selected = -selected;

		

		selected = Math.round(this.angle/this.slices) - selected*12;

		if (selected < 0)

			selected = 12 + selected;

			

		return [selected, this.values[selected]];

	}

};



function loaded() {

	window.scrollTo(0,0);

	var i, lis, theTransform, matrix;

	

	lis = document.getElementsByTagName('li');

	for(i=0; i<lis.length; i+=1) {

		theTransform = window.getComputedStyle(lis[i]).webkitTransform;

		matrix = new WebKitCSSMatrix(theTransform).translate(0, 100);

		lis[i].style.webkitTransform = matrix;

	}





function detectsocial() {



if (social.getSelectedValue() == "10,Reddit") 

	{  

	document.location.href='http://www.reddit.com/';

	}

else if 	(social.getSelectedValue() == "11,Digg") 

	{  

	document.location.href='http://digg.com/';

	}

else if (social.getSelectedValue() == "9,Newsvine")

	{

	document.location.href='http://www.newsvine.com/';

	}

else if (social.getSelectedValue() == "8,Delicious")

	{

	document.location.href='http://del.icio.us/';

	}

else if (social.getSelectedValue() == "7,Stumbleupon")

	{

	document.location.href='http://www.stumbleupon.com/';

	}

else if (social.getSelectedValue() == "6,Facebook")

	{

	document.location.href='http://www.facebook.com/';

	}

else if (social.getSelectedValue() == "5,friendfeed")

	{

	document.location.href='http://friendfeed.com/';

	}

else if (social.getSelectedValue() == "4,Mixx")

	{

	document.location.href='http://www.mixx.com/';

	}

else if 	(social.getSelectedValue() == "3,MySpace") 

	{  

	document.location.href='http://www.myspace.com/';

	}

else if 	(social.getSelectedValue() == "2,Netvibes") 

	{  

	document.location.href='http://www.netvibes.com/';

	}

else if 	(social.getSelectedValue() == "1,Technorati") 

	{  

	document.location.href='http://technorati.com/';

	}

else if 	(social.getSelectedValue() == "0,Twitter") 

	{  

	 document.location.href='http://m.twitter.com';

	}

else

   {

   alert("Good Evening dear visitor");

   }

   

	}

	

	

	social.init();

	

	document.getElementById('ok').addEventListener('click', detectsocial , false);

}

window.addEventListener("load", function() { setTimeout(loaded, 100); }, true);