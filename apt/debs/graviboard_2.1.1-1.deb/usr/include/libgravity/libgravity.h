//
//  GVPhysicsController.h
//  libgravity
//
//  Created by Conrad Kramer on 3/19/13.
//  Copyright (c) 2013 Kramer Software Productions, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

class b2World;
class b2Body;

@interface GVPhysicsController : NSObject 

@property (readonly, nonatomic) NSArray *containers;

@property (readonly, nonatomic) UIView *rootView;

@property (readonly, nonatomic) NSMapTable *bodyMap;

@property (readonly, nonatomic) b2Body *edgeBody;

@property (readonly, nonatomic) b2World *world;

@property (readonly, atomic) BOOL simulating;

@property (nonatomic, getter=isDebugDrawEnabled) BOOL debugDrawEnabled;

@property (nonatomic) UIInterfaceOrientation orientation;

@property (nonatomic) float gravity;

@property (nonatomic) float restitution;

@property (nonatomic) float friction;

+ (instancetype)controllerWithContainers:(NSArray *)containers;

- (id)initWithContainers:(NSArray *)containers;

- (void)play;

- (void)stop:(BOOL)animated;

@end
